<?php 
session_start();

$conn = mysqli_connect("localhost", "root", "", "foody") or die(mysqli_connect_error());

$data = mysqli_query($conn, "SELECT * FROM user WHERE user_name = '".$_SESSION['rider']."'");
$data2 = mysqli_query($conn, "SELECT * FROM rider WHERE rider_name = '".$_SESSION['rider']."'");

$test = mysqli_fetch_row($data);
$test2 = mysqli_fetch_row($data2);




?>

<?php include('partials/top.php'); ?>

        <div class="main">
            <div class="info">
				<!--<div><img src="../images/profile.jpg" alt="Profile Picture"></div>-->
				<div>
                        <table class="tbl-profile">
                            <tr>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Contact Number</th>
                                <th>Plate Number</th>
                            </tr>

                                
                           
                            <tr>
                                <td><?php echo $test[0]; ?></td>
                                <td><?php echo $test[1]; ?></td>
                                <td><?php echo $test[4]; ?></td>
                                <td><?php echo $test2[1]; ?></td>
                            </tr>

                                            
                            
                        </table>
				</div>
				<button class="order_profile" onclick="window.location.href = 'rider_profileEdit.php';">Edit Profile</button>
                <!--<a href="" class="order_profile">Edit</a>-->
            </div>
        </div>
    </div>

    

    <?php include('partials/footer.php'); //sadadsadasdasd?>