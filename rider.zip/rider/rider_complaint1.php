<?php 
session_start();

$conn = mysqli_connect("localhost", "root", "", "foody") or die(mysqli_connect_error());
$data = mysqli_query($conn, "SELECT DISTINCT complaint_date FROM complaint ORDER BY complaint_date ASC");
$test = mysqli_fetch_all($data);
//print_r($test);
?>
<?php include('partials/top.php'); ?>

<div class="main">
            <div class="info">
			<H2>Choose a Date<br><br></h2>
			<form action="rider_complaint2.php" method="GET">
				<div>
					<select class="comp" name="complaint_date" id="complaint_date" required>
						<option value=""></option>
						<?php 
						foreach($test as $value) 
							{
								echo '<option value="' . $value[0] . '">' . $value[0] . '</option>';
							}
						?>
					</select>
				</div>
						<H2>Complaint List</H2><br><br>
				<div>
					<select class="comp" name="complain_type" id="complaint_type" required>
						<option value=""></option>	
						<option value="late">Late Delivery</option>
						<option value="pack">Package Damaged</option>
						<option value="bill">Billing</option>
						<option value="oth">Others</option>
					</select><br>
				</div>
				<button type="submit" class="check_compl">View Complaint</button>
			</form>
				
            </div>
        </div>
    </div>

<?php include('partials/footer.php'); ?>