<?php include('partials/top.php'); ?>

<
        <div class="main">
            <div class="info">
				<h2>Complaint Type</h2><br>
				<p><span id="complaint_type"/><p>
				<h2>Complaint Description</h2><br>
				<p><span id="complaint_desc"/><p>
				<h2>Write a Feedback</h2><br>
				<textarea class="comp_desc" id="comp_desc" name="comp_desc" rows="4" cols="50">
				
				</textarea><br>
				
				<button class="sub_feed" >Submit Feedback</button>
				<button class="sub_feed" onclick="window.location.href = 'rider_complaint1.html';">Go Back</button>
            </div>
        </div>
    </div>

    <footer><hr><br> &copy 2022 All Right Reserve</footer>
    
</body>
</html>