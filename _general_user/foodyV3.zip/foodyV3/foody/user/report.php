<!--
    This class is for the report page
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Foody: UMP Food Delivery System</title>
    <link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <style>
        .main{
            height: 500px;
        }

        table{
            width: 900px;
        }
        table, th, td{
            border-collapse: collapse;
            border: 1px solid #990000;
            padding: 12px;
            margin-top: 16px;
            margin-left: auto;
            margin-right: auto;
        }

        th{
            color: #fff;
            background-color: #990000;
        }
    </style>
    </style>
</head>
<body>
    <header>
        <img src="images/foody logo.png" alt="Foody Logo">
        <ul>
            <li><h1>Foody</h1></li>
            <li><p>UMP Food Delivery System</p></li>
        </ul>
        <a href="#"></a><button class="logout" >Logout</button>
    </header>

    <div class="row">
        <div class="sidebar">
            <h2>Report</h2>
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="list.php"><i class="fa fa-utensils"></i> Restaurant</a></li>
                <li><a href="order.php"><i class="fas fa-address-card"></i> Orders</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="#"><i class="fas fa-exclamation"></i> Complaint</a></li>
                <li><a href="report.php"><i class="fas fa-file"></i> Report</a></li>
            </ul> 
            </div>
        <div class="main">
            <div class="title">
                <h1>Expenses Report</h1>
            </div>

            <div class="type">
                <label for="event">Calculate expenses based on: </label>
                <select name="event" id="events">
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                </select>
            </div>

            <div class="report">
                <table>
                    <tr>
                        <th>Expenses</th>
                        <th>Type of Food</th>
                        <th>Total (RM)</th>
                    </tr>
                    <tr>
                        <th rowspan="6">Maximum</th>
                        <td>Beverage</td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <td>Nasi</td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <td>Burger</td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <td>Noodles</td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <td>Deserts</td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <td>Seafood</td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <th>Total</th>
                        <td rowspan="2"></td>
                        <td><input type="number"></td>
                    </tr>
                    <tr>
                        <th>Average</th>
                        <td><input type="number"></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <footer><hr><br> &copy 2022 All Right Reserve</footer>
    
</body>
</html>