<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Foody: UMP Food Delivery System</title>
    <link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script src="script.js"></script>
</head>
<script>
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
   dd = '0' + dd;
}

if (mm < 10) {
   mm = '0' + mm;
} 
    
today = yyyy + '-' + mm + '-' + dd;
document.getElementById("end").setAttribute("max", today);
</script>
<style>
.date { 
	padding: 10px;
	margin-right: 20px;
	margin-bottom: 20px;
	} 
	
.main .info .comp {
	padding: 10px;
	margin-right: 20px;
	margin-bottom: 100px;
	}
	
.check_compl{ 
	align: center;
    color: #990000;
    padding: 8px 12px;
    border-radius: 8px; 
    border: 2px solid #990000;
    background-color: white; 
	margin-left: 500px;
	font-size: 16px;
}

.check_compl:hover{
	color: white;
    background-color: #990000;
	transform: scale(1.1);
}


</style>
<body>
    <header>
        <img src="foody logo.png" alt="Foody Logo">
        <ul>
            <li><h1>Foody</h1></li>
            <li><p>UMP Food Delivery System</p></li>
        </ul>
        <a href="#"></a><button class="logout" >Logout</button>
    </header>

    <div class="row">
        <div class="sidebar">
            <h2>Complaint</h2>
            <ul>
                <li><a href="rider_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="rider_orders.php"><i class="fas fa-address-card"></i> Orders</a></li>
                <li><a href="rider_profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="rider_complaint1.php"><i class="fas fa-exclamation"></i> Complaint</a></li>
                <li><a href="rider_report1.php"><i class="fas fa-file"></i> Report</a></li>
            </ul> 
            </div>
        <div class="main">
            <div class="info">
			<H2>Choose a Date<br><br></h2>
				<div>
					<label for="start">From:</label>
					<input class="date" type="date" id="start" name="start" value="" min="2022-01-01" max="2022-12-31">
					<label for="end">Until:</label>
					<input class="date" type='date' id="end" name="end" min='2022-01-01' max='2022-12-31'></input>
				</div>
				<H2>Complaint List</H2><br><br>
				<div>
				<select class="comp" name="list" id="list">
					<option class="comp" value="late">Late Delivery</option>
					<option class="comp" value="pack">Package Damaged</option>
					<option class="comp" value="bill">Billing</option>
					<option class="comp" value="oth">Others</option>
				</select><br>
				</div>
				<button class="check_compl" onclick="window.location.href = 'rider_complaint2.html';">View Complaint</button>
            </div>
        </div>
    </div>

    <footer><hr><br> &copy 2022 All Right Reserve</footer>
    
</body>
</html>