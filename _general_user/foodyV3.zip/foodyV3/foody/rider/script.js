/*window.addEventListener('load', () => {
	
	const params = (new URL(document.location)).searchParams;
	const rider-name = params.get('rider-name');
	const rider-num = params.get('rider-num');
	const rider-plate = params.get('rider-plate');
	
	document.getElementById('rider-name').innerHTML = rider-name;
	document.getElementById('rider-num').innerHTML = rider-num;
	document.getElementById('rider-plate').innerHTML = rider-plate;
})*/

/*function handleSubmit () {
	const rider-name = documents.getElementById('rider-name').value;
	const rider-num = documents.getElementById('rider-name').value;
	const rider-plate = documents.getElementById('rider-name').value;
	
	localStorage.setItem("RIDERNAME", rider-name);
	localStorage.setItem("RIDERNUM", rider-num)
	localStorage.setItem("RIDERPLATE", rider-plate)
	
	return;
}*/