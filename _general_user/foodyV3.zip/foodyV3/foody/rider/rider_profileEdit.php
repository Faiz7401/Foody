<?php session_start();
	$_SESSION["StartTime"] = date("r");
	echo $_SESSION["StartTime"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Foody: UMP Food Delivery System</title>
    <link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script type="text/javascript" src="script.js"></script>
</head>
<style>
table {
	text-align: left;
	font-size: 16px;
	margin-left: 10px;
	}
	
th, td {
padding: 10px;
}
	
.order_profile{ 
	align: center;
    color: #990000;
    padding: 8px 12px;
    border-radius: 8px; 
    border: 2px solid #990000;
    background-color: white; 
	margin-left: 10px;
	}
	
.order_profile:hover {
    color: white;
    background-color: #990000;
	transform: scale(1.1);
}

.main .info .rider_profile .profile_edit {
	padding: 7px;
	padding-right: 300px;
}
</style>
<body>
    <header>
        <img src="foody logo.png" alt="Foody Logo">
        <ul>
            <li><h1>Foody</h1></li>
            <li><p>UMP Food Delivery System</p></li>
        </ul>
        <a href="#"></a><button class="logout" >Logout</button>
    </header>

    <div class="row">
        <div class="sidebar">
            <h2>Profile</h2>
            <ul>
                <li><a href="rider_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="rider_orders.php"><i class="fas fa-address-card"></i> Orders</a></li>
                <li><a href="rider_profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="rider_complaint1.php"><i class="fas fa-exclamation"></i> Complaint</a></li>
                <li><a href="rider_report1.php"><i class="fas fa-file"></i> Report</a></li>
            </ul>
            </div>
			
        <div class="main">
            <div class="info">
				<div><img src="quandale.jpg" alt="Foody Logo"></div>
				<div>
					<form action="rider_profile.php" method="GET">
						Rider Name: <input class="profile_edit" type="text" id="rider_name" name="rider_name" value=""/><br>
						Rider Contact Number: <input class="profile_edit" type="text" id="rider_number" name="rider_number" value=""/><br>
						Rider Plate Number: <input class="profile_edit" type="text" id="rider_plateNum" name="rider_plateNum" value=""/><br>
						<input type="submit" class="order_profile" name="submit" value="Submit"/>
					</form>
					<button class="order_profile" onclick="window.location.href = 'rider_profile.php';">Go Back</button>	
				</div>
            </div>
        </div>
    </div>

    <footer><hr><br> &copy 2022 All Right Reserve</footer>
    
</body>
</html>

<?php

function pre_r( $array ){
	echo '<pre>';
	print_r($array);
	echo '</pre>';
}
?>