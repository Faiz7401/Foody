<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Foody: UMP Food Delivery System</title>
    <link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script src="script.js"></script>
</head>
<style>
.date { 
	padding: 10px;
	margin-right: 20px;
	margin-bottom: 20px;
	} 
	
.commision {
	padding: 10px;
	margin-right: 20px;
	margin-bottom: 20px;
	}
	
.check_report{ 
	align: center;
    color: #990000;
    padding: 8px 12px;
    border-radius: 8px; 
    border: 2px solid #990000;
    background-color: white; 
	margin-left: 500px;
	font-size: 16px;
}

.check_report:hover{
	color: white;
    background-color: #990000;
	transform: scale(1.1);
}
</style>
<body>
    <header>
        <img src="foody logo.png" alt="Foody Logo">
        <ul>
            <li><h1>Foody</h1></li>
            <li><p>UMP Food Delivery System</p></li>
        </ul>
        <a href="#"></a><button class="logout" >Logout</button>
    </header>

    <div class="row">
        <div class="sidebar">
            <h2>Report</h2>
            <ul>
                <li><a href="rider_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="rider_orders.php"><i class="fas fa-address-card"></i> Orders</a></li>
                <li><a href="rider_profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="rider_complaint1.php"><i class="fas fa-exclamation"></i> Complaint</a></li>
                <li><a href="rider_report1.php"><i class="fas fa-file"></i> Report</a></li>
            </ul> 
            </div>
        <div class="main">
            <div class="info">
			<H2>Commision</H2><br><br>
				<div>
				<select class="commision" name="list" id="list">
					<option class="commision" value="weekly">Weekly</option>
					<option class="commision" value="monthly">Monthly</option>
					<option class="commision" value="overall">Overall</option>
					<option class="commision" value="other">Specific Date</option>
				</select><br>
				</div>
				<h2>For Specific Date:<h2><br><br>
				<div>
					<label for="start">From:</label>
					<input class="date" type="date" id="start" name="start" value="" min="2022-01-01" max="2022-12-31">
					<label for="end">Until:</label>
					<input class="date" type='date' id="end" name="end" min='2022-01-01' max='2022-12-31'></input>
				</div>
				<button class="check_report" onclick="window.location.href = 'rider_report2.html';">Generate Report</button>
			</div>
        </div>
    </div>

    <footer><hr><br> &copy 2022 All Right Reserve</footer>
    
</body>
</html>