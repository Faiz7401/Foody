<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Foody: UMP Food Delivery System</title>
    <link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script src="script.js"></script>
</head>

<style>
.main .info .order_title{
	font-align: right;
    margin: 20px;
    color: black;
    line-height: 25px;
}

table, th, td	{
		width: 800px;
		border-collapse: collapse;
		margin: 25px 50px 75px 100px;
		font-size: 16px;
		min-width: 100px;	 
		font-family: calibri;
		border: 2px solid #CE2029;
		padding: 35px;
		resize: both;
		overflow: auto;
		}
		
th 	{	 
		background-color: #990000;
		text-align: left;
		color: white;
		padding-right: 1px;
		width: 33%;
		}
		
td	{
		text-align: left;
		color: #717171;
		padding-right: 1px;
	}
		
.order_status{ 
	align: center;
    color: #990000;
    padding: 8px 12px;
    border-radius: 8px; 
    border: 2px solid #990000;
    background-color: white; 
	margin-left: 130px;
	font-size: 16px;
}

.order_status:hover {
    color: white;
    background-color: #990000;
	transform: scale(1.1);
}
</style>

<body>
    <header>
        <img src="foody logo.png" alt="Foody Logo">
        <ul>
            <li><h1>Foody</h1></li>
            <li><p>UMP Food Delivery System</p></li>
        </ul>
        <a href="#"></a><button class="logout" >Logout</button>
    </header>

    <div class="row">
        <div class="sidebar">
            <h2>Orders</h2>
            <ul>
                <li><a href="rider_home.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="rider_orders.php"><i class="fas fa-address-card"></i> Orders</a></li>
                <li><a href="rider_profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="rider_complaint1.php"><i class="fas fa-exclamation"></i> Complaint</a></li>
                <li><a href="rider_report1.php"><i class="fas fa-file"></i> Report</a></li>
            </ul> 
            </div>
        <div class="main">
            <div class="info">
                <div class= "order_title"><h2>Current Orders</h2></div>
				<div class="order_table">
					<table>
						<tr>
							<th>Restaurant</th>
							<td>aaaaaaaaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaaa</td>
						</tr>
						<tr>
							<th>Menu Item(s)</th>
							<td>aaaaaaaaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaaa</td>
						</tr>
						<tr>
							<th>Customer Name</th>
							<td>aaaaaaaaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaaa</td>
						</tr>
						<tr>
							<th>Customer Address</th>
							<td>aaaaaaaaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaaa</td>
						</tr>
						<tr>
							<th>Customer Contact No.</th>
							<td>aaaaaaaaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaaa</td>
						</tr>
					</table>
				</div>
				<a href="#"></a><button class="order_status" >Preparing</button>
				<a href="#"></a><button class="order_status" >Picked Up</button>
				<a href="#"></a><button class="order_status" >Delivered</button>
				<a href="#"></a><button class="order_status" >Cancelled</button>
			</div>
        </div>
    </div>

    <footer><hr><br> &copy 2022 All Right Reserve</footer>
    
</body>
</html>